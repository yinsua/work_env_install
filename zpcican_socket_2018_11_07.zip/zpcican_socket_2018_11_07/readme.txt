1. copy sja1000.h to current directory.
	# cp /usr/src/your-kernel-source/drivers/net/can/sja1000/sja1000.h .

2. edit Makefile, change KDIR to your kernel directory.

3. compile & load zpcican.ko.
	# make
	# modprobe sja1000
	# insmod zpcican.ko

4. install can-utils.
	# apt-get update
	# apt-get install can-utils

5. check hardware.
	# lspci -n

6. check device node.
	# ls /sys/class/net/can*

7. bring up net interface.
	# ip link set can0 type can bitrate 125000 triple-sampling on
	# ip link set can1 type can bitrate 500000 triple-sampling on
	# ifconfig can0 up
	# ifconfig can1 up

8. receive.
	# candump any

9. send.
	# cansend can0 123#11.22.33.44.55.66.77.88