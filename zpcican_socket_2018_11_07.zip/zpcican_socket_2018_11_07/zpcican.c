/*
* ZHIYUAN PCI/PCIE-CAN device driver
* Copyright (C) Guangzhou ZHIYUAN Electronics Co., Ltd. All rights reserved.
*/
#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/can.h>
#include "sja1000.h"

#define PCIXX_MODULE_INFO  "zhiyuan pci/pcie-can"
#define PCIXX_DRIVER_NAME  "zpcican"
#define PCIXX_DRIVER_VERS  "1.0"
static const struct pci_device_id pcixx_id_table[] = {
    {0x10b5, 0x9811, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0},
    {0x10b5, 0x5201, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0},
    {0x10b5, 0x9821, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0},
    {0x10b5, 0x9840, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0},
    {0x10b5, 0x9110, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0},
    {0x10b5, 0x9120, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0},
    {0x10b5, 0x9140, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0},
    {0}
};
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION(PCIXX_MODULE_INFO);
MODULE_DEVICE_TABLE(pci, pcixx_id_table);

static unsigned dbg = 0;
module_param(dbg, uint, 0644);
#define _DBG_(fmt, args...)  if (dbg) { printk(KERN_ERR PCIXX_DRIVER_NAME ": %s(%d): " fmt "\n", __FUNCTION__, __LINE__, ##args); }
#define _MSG_(fmt, args...)  printk(KERN_ERR PCIXX_DRIVER_NAME ": %s(%d): " fmt "\n", __FUNCTION__, __LINE__, ##args)

#define PCIXX_MAX_BARS  6
#define PCIXX_MAX_PORTS  4
#define R_REG8(base,reg)  readb((u8*)(base)+(reg))
#define R_REG32(base,reg)  readl((u32*)(base)+(reg))
#define W_REG8(base,reg,val)  writeb(val,(u8*)(base)+(reg))
#define W_REG32(base,reg,val)  writel(val,(u32*)(base)+(reg))
#define R_BAR32(base,offs)  readl((u32*)((u8*)(base)+(offs)))
#define W_BAR32(base,offs,val)  writel(val,(u32*)((u8*)(base)+(offs)))
#define SJA_TO_PORT(sja)  ((pcixx_port*)(*(void**)((sja)->priv)))

enum { PCI9810I, PCI9820, PCI9820I, PCI9840, PCIE9110, PCIE9120, PCIE9140, PCIXX_HW_TYPES };
int pcixx_ports[] = {1, 2, 2, 4, 1, 2, 4};
typedef struct {
    int type;
    void __iomem *reg_base;
    struct net_device *ndev;
} pcixx_port;
typedef struct {
    struct pci_dev *pcidev;
    struct {
        size_t start;
        size_t end;
        size_t size;
        void __iomem *ptr;
    } bars[PCIXX_MAX_BARS];
    int type;
    int nports;
    pcixx_port ports[PCIXX_MAX_PORTS];
} pcixx_device;

static u8 pcixx_read(const struct sja1000_priv *priv, int reg)
{
    pcixx_port *port = SJA_TO_PORT(priv);
    return (port->type <= PCI9840) ? R_REG8(port->reg_base, reg) : R_REG32(port->reg_base, reg);
}
static void pcixx_write(const struct sja1000_priv *priv, int reg, u8 val)
{
    pcixx_port *port = SJA_TO_PORT(priv);
    if (port->type <= PCI9840) W_REG8(port->reg_base, reg, val);
    else W_REG32(port->reg_base, reg, val);
}

static void pcixx_map_bars(pcixx_device *d)
{
    int i;
    for (i = 0; i < PCIXX_MAX_BARS; i++) {
        if (!pci_resource_len(d->pcidev, i)) continue;
        d->bars[i].start = pci_resource_start(d->pcidev, i);
        d->bars[i].end = pci_resource_end(d->pcidev, i);
        d->bars[i].size = d->bars[i].end + 1 - d->bars[i].start;
        d->bars[i].ptr = pci_iomap(d->pcidev, i, d->bars[i].size);
        _MSG_("bar%d: 0x%x~0x%x, len=0x%x(%u), ptr=0x%p",
            i, (unsigned)d->bars[i].start, (unsigned)d->bars[i].end,
            (unsigned)d->bars[i].size, (unsigned)d->bars[i].size, d->bars[i].ptr);
    }
}
static void pcixx_unmap_bars(pcixx_device *d)
{
    int i;
    for (i = 0; i < PCIXX_MAX_BARS; i++) {
        if (!d->bars[i].ptr) continue;
        _MSG_("bar%d: 0x%x~0x%x, len=0x%x(%u), ptr=0x%p",
            i, (unsigned)d->bars[i].start, (unsigned)d->bars[i].end,
            (unsigned)d->bars[i].size, (unsigned)d->bars[i].size, d->bars[i].ptr);
        pci_iounmap(d->pcidev, d->bars[i].ptr);
        d->bars[i].ptr = NULL;
    }
}

static int pcixx_hw_detect(struct pci_dev *dev)
{
    int ret, i;
    u16 vendor, device;
    ret = pci_read_config_word(dev, PCI_VENDOR_ID, &vendor);
    if (ret) {
        _MSG_("pci_read_config_word(PCI_VENDOR_ID) failed");
        return ret;
    }
    ret = pci_read_config_word(dev, PCI_DEVICE_ID, &device);
    if (ret) {
        _MSG_("pci_read_config_word(PCI_DEVICE_ID) failed");
        return ret;
    }
    for (i = 0; i < PCIXX_HW_TYPES; i++) {
        if (vendor == pcixx_id_table[i].vendor && device == pcixx_id_table[i].device)
            return i;
    }
    _MSG_("unknown device: vendor=0x%04x, device=0x%04x", vendor, device);
    return -1;
}
static void pcixx_hw_init(pcixx_device *d, int init)
{
    void *base = d->bars[0].ptr;
    int offs = d->type <= PCI9840 ? 0x4c : 0x2004;
    u32 val = !!(init & 2);
    _MSG_("***");
    if ((init & 1) && (d->type <= PCI9840)) {
        W_BAR32(base, 0x28, 0x55215081);
        W_BAR32(base, 0x2c, 0x55215081);
        W_BAR32(base, 0x30, 0x55215081);
        W_BAR32(base, 0x34, 0x55215081);
    }
    if (d->type <= PCI9840) {
        enum { Linti1Enable = 1, Linti2Enable = 1 << 3, PciInterruptEnable = 1 << 6 };
        val = R_BAR32(base, offs);
        if (init & 2) val |= Linti1Enable | Linti2Enable | PciInterruptEnable; 
        else val &= ~(Linti1Enable | Linti2Enable | PciInterruptEnable);
    }
    W_BAR32(base, offs, val);
}

static void pcixx_remove(struct pci_dev *dev)
{
    pcixx_device *d = pci_get_drvdata(dev);
    int i;
    _MSG_("+++");
    pci_set_drvdata(dev, NULL);
    if (d) {
        for (i = 0; i < d->nports; i++) {
            if (!d->ports[i].ndev) continue;
            _DBG_("unregister_sja1000dev(port%d)", i);
            unregister_sja1000dev(d->ports[i].ndev);
            free_sja1000dev(d->ports[i].ndev);
        }
        pcixx_unmap_bars(d);
        _MSG_("kfree(device)");
        kfree(d);
    }
    pci_release_regions(dev);
    pci_disable_device(dev);
    _MSG_("---");
}
static int pcixx_probe(struct pci_dev *dev, const struct pci_device_id *id)
{
    int err = -ENODEV, hw, i;
    pcixx_device *d = NULL;
    pcixx_port *port = NULL;
    struct sja1000_priv *sja = NULL;

    _MSG_("+++ dev=0x%p", dev);
    do {
        pci_set_drvdata(dev, d);
        if (pci_enable_device(dev)) {
            _MSG_("pci_enable_device failed");
            break;
        }
        _DBG_("pci_enable_device succeeded");
        pci_set_master(dev);
        if (pci_request_regions(dev, PCIXX_DRIVER_NAME)) {
            _MSG_("pci_request_regions failed");
            break;
        }
        _DBG_("pci_request_regions succeeded");
        hw = pcixx_hw_detect(dev);
        if (hw < 0) {
            _MSG_("pcixx_hw_detect failed");
            break;
        }
        _DBG_("pcixx_hw_detect succeeded: hw=%d", hw);
        d = kzalloc(sizeof(*d), GFP_KERNEL);
        if (!d) {
            _MSG_("kzalloc(%u) failed", (unsigned)sizeof(*d));
            break;
        }
        _DBG_("kzalloc(%u) succeeded", (unsigned)sizeof(*d));

        d->type = hw;
        d->nports = pcixx_ports[hw];
        pci_set_drvdata(dev, d);
        d->pcidev = dev;
        pcixx_map_bars(d);
        pcixx_hw_init(d, 1);
        for (i = 0; i < d->nports; i++) {
            port = &d->ports[i];
            port->type = hw;
            port->ndev = alloc_sja1000dev(sizeof(void*));
            if (!port->ndev) {
                _MSG_("alloc_sja1000dev(port%u) failed", i);
                continue;
            }
            _DBG_("alloc_sja1000dev(port%u) succeeded", i);
            sja = netdev_priv(port->ndev);
            *(void**)(sja->priv) = port;
            switch (d->type) {
            case PCI9810I: case PCI9820: port->reg_base = d->bars[2 + i].ptr; break;
            case PCI9820I: case PCI9840: port->reg_base = d->bars[1 + d->nports - i].ptr; break;
            case PCIE9110: case PCIE9120: case PCIE9140:
                port->reg_base = (u8*)(d->bars[0].ptr) + 0x400 * i;
                break;
            }
            sja->reg_base = port->reg_base;
            sja->read_reg = pcixx_read;
            sja->write_reg = pcixx_write;
            sja->can.clock.freq = 8000000;
            sja->ocr = OCR_TX0_PUSHPULL;
            sja->cdr = CDR_CBP | CDR_CLKOUT_MASK;
            sja->irq_flags = IRQF_SHARED;
            port->ndev->dev_id = i;
            port->ndev->irq = dev->irq;
            SET_NETDEV_DEV(port->ndev, &dev->dev);
            err = register_sja1000dev(port->ndev);
            if (err) {
                _MSG_("register_sja1000dev(port%u) failed", i);
                free_sja1000dev(port->ndev);
                port->ndev = NULL;
                continue;
            }
            _DBG_("register_sja1000dev(port%u) succeeded", i);
        }
        pcixx_hw_init(d, 2);
        err = 0;
    } while (0);
    if (err) pcixx_remove(dev);
    _MSG_("--- err=%d", err);
    return err;
}

static int pcixx_suspend(struct pci_dev *dev, pm_message_t state)
{
    pcixx_device *d = pci_get_drvdata(dev);
    _DBG_("+++ type=%d", d->type);
    pci_save_state(dev);
    pci_disable_device(dev);
    pci_set_power_state(dev, pci_choose_state(dev, state));
    _DBG_("---");
    return 0;
}
static int pcixx_resume(struct pci_dev *dev)
{
    pcixx_device *d = pci_get_drvdata(dev);
    int err;
    _DBG_("+++ type=%d", d->type);
    pci_set_power_state(dev, PCI_D0);
    pci_restore_state(dev);
    err = pci_enable_device(dev);
    if (!err && d) pcixx_hw_init(d, 3);
    _DBG_("--- pci_enable_device: err=%d", err);
    return err;
}
static struct pci_driver pcixx_driver = {
    .name = PCIXX_DRIVER_NAME,
    .id_table = pcixx_id_table,
    .probe = pcixx_probe,
    .remove = pcixx_remove,
    .suspend = pcixx_suspend,
    .resume = pcixx_resume,
};
module_pci_driver(pcixx_driver);
